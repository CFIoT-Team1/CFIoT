// vite.config.js
export default {
    server: {
      host: true, // 等同於 0.0.0.0，對外開放
      port: 5173
    }
  }
  