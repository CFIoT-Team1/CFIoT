import React, { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  LinearScale,
  Title,
  CategoryScale,
  Tooltip,
  Legend
} from "chart.js";

ChartJS.register(
  LineElement,
  PointElement,
  LinearScale,
  Title,
  CategoryScale,
  Tooltip,
  Legend
);

export default function ElectricMeterDashboard() {
  const [data, setData] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  const [range, setRange] = useState("1d");

  useEffect(() => {
    const fetchData = async () => {
      const res = await fetch("/mock/electric-data.json");
      const json = await res.json();
      setData(json);
    };
    fetchData();
  }, []);

  if (!data) return <div className="p-4">Loading...</div>;

  const getFilteredHistory = () => {
    const all = data.history;
    if (range === "7d") return all.slice(-7);
    if (range === "30d") return all.slice(-30);
    return all.slice(-1); // 1 day
  };

  const filteredHistory = getFilteredHistory();

  const chartData = {
    labels: filteredHistory.map((entry) => entry.time),
    datasets: [
      {
        label: "Energy Consumption (kWh)",
        data: filteredHistory.map((entry) => entry.kWh),
        fill: false,
        tension: 0.3,
        borderColor: darkMode ? "#4ade80" : "#3b82f6",
        borderWidth: 2
      }
    ]
  };

  return (
    <div
      className={`min-h-screen px-4 py-6 sm:px-8 sm:py-10 transition-colors duration-300 font-sans ${
        darkMode ? "bg-gray-900 text-white" : "bg-white text-gray-900"
      }`}
    >
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6">
          <h1 className="text-3xl font-bold text-center sm:text-left">📊 Electric Meter Dashboard</h1>
          <button
            className="px-4 py-2 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-800"
            onClick={() => setDarkMode(!darkMode)}
          >
            {darkMode ? "☀️ Light Mode" : "🌙 Dark Mode"}
          </button>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <div className="space-y-3 text-base">
            <p>🔋 Voltage: <span className="font-semibold">{data.voltage} V</span></p>
            <p>🔌 Current: <span className="font-semibold">{data.current} A</span></p>
            <p>⚡ Power: <span className="font-semibold">{data.power} W</span></p>
            <p>📈 Energy Today: <span className="font-semibold">{data.energy_today} kWh</span></p>
            <p>🕒 Last Updated: <span className="font-semibold">{new Date(data.timestamp).toLocaleString()}</span></p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-4">🔌 Energy Usage Chart</h2>
            <Line data={chartData} />
            <div className="mt-4 flex gap-2 justify-center">
              <button onClick={() => setRange("1d")} className={`px-3 py-1 rounded border ${range === "1d" ? "bg-blue-500 text-white" : "bg-white text-gray-800"}`}>1 Day</button>
              <button onClick={() => setRange("7d")} className={`px-3 py-1 rounded border ${range === "7d" ? "bg-blue-500 text-white" : "bg-white text-gray-800"}`}>7 Days</button>
              <button onClick={() => setRange("30d")} className={`px-3 py-1 rounded border ${range === "30d" ? "bg-blue-500 text-white" : "bg-white text-gray-800"}`}>30 Days</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}